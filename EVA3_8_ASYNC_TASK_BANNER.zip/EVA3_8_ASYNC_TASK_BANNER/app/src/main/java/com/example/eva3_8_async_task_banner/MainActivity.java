package com.example.eva3_8_async_task_banner;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {
    Bitmap bitmap;
    ImageView imagen;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txtVwMostrar = findViewById(R.id.txtVwMostrar);
        imagen = findViewById(R.id.imgVwImagen);
        MiClaseAsin miClase = new MiClaseAsin();
        bitmap = BitmapFactory.decodeFile("Direccion url");
        imagen.setImageBitmap(bitmap);
        miClase.execute(20, 500);
    }
}

class MiClaseAsin extends AsyncTask <Integer, String, String> {
    //TODOS PUEDEN INTERACTUAR CON LA UI, EXCEPTO doInBackground
    @Override
    protected void OnPreExecute(){
        super.onPreExecute();
        txtVwMostrar.setText("Inicia la app");
    }

    @Override
    protected String onProgressUpdate(String... values){
        super.onProgressUpdate(values);
        txtVwMostrar.append(values[0]);
    }

    @Override
    protected String doInBackground(String... strings){
        int iVeces = Integers[0];
        int iDemora[1];
        for (int i = 0; i<iVeces; i++){
            try{
                Thread.sleep(iDemora);
                publishProgress(i + " - ");
            } catch(InterruptedException e){
                e.printStackTrace();
            }
        }
        return "FIN DEL ASYNKTASK";
    }

    @Override
    protected String onPostExecute(String s){
        super.onPreExecute(s);
        txtVwMostrar.append(s);
    }
}
