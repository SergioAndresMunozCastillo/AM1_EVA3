package com.example.eva2_13_media_player;

import androidx.appcompat.app.AppCompatActivity;

import android.media.MediaPlayer;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    MediaPlayer mediaplayer = null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mediaplayer = MediaPlayer.create(this, R.raw.acdc_back_in_black);
    }

    @Override
    protected void onStop() {
        super.onStop();
        if(mediaplayer != null){
            mediaplayer.stop();
            mediaplayer.release();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if(mediaplayer != null){
            mediaplayer.start();
        }
    }
}
