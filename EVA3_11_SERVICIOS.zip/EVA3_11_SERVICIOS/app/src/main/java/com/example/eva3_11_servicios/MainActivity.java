package com.example.eva3_11_servicios;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {
    Intent intento;
    TextView txtVwDatos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txtVwDatos = findViewById(R.id.txtVwDatos);
        intento = new Intent(this, MyService.class);
    }
    @Override
    public void onStart(Intent intent, int startId){
        super.onStart(intent,startId);
        Log.wtf("MyService", "onSTart");
    }

    new Thread(){
        @Override
                public void run(){
            super.run();
            while(true){
                try{
                    Thread.sleep(500);
                    Log.wtf("Myservice", "Tarea en segundo plano");
                }catch ()
            }
        }.start();
    }

    public void iniServicio(View v){
        startService(intento);
    }
    public void finServicio(View v){
        stopService(intento);
    }
}
