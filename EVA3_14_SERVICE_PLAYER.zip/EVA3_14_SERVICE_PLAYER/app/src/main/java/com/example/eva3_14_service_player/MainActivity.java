package com.example.eva3_14_service_player;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {
Intent media = null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        media = new Intent(this, ServicioMedia.class);

    }

    public void iniciarServ (View v){
        startService(media);
    }

    public void detenerServ (View v){
        stopService(media);
    }

}
