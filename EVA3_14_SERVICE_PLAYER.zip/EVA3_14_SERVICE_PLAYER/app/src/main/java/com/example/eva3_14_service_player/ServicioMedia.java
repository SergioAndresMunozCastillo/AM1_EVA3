package com.example.eva3_14_service_player;

import android.app.Service;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.IBinder;

public class ServicioMedia extends Service {

    MediaPlayer mediatico = null;

    public ServicioMedia() {
    }

    @Override
    public IBinder onBind(Intent intent) {
        // TODO: Return the communication channel to the service.
        throw new UnsupportedOperationException("Not yet implemented");
    }

    @Override
    public void onCreate() {
        super.onCreate();
        mediatico = MediaPlayer.create(getApplicationContext(), R.raw.acdc_back_in_black);
    }

    @Override
    public void onStart(Intent intent, int startId) {
        super.onStart(intent, startId);
        if(mediatico != null){
            mediatico.start();
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if(mediatico != null){
            mediatico.stop();
            mediatico.release();
        }
    }
}
