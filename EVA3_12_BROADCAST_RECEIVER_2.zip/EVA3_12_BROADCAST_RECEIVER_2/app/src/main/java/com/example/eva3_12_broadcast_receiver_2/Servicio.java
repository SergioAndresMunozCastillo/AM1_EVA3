package com.example.eva3_12_broadcast_receiver_2;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;

public class Servicio extends Service {
    public Servicio() {
    }

    @Override
    public IBinder onBind(Intent intent) {
        // TODO: Return the communication channel to the service.
        throw new UnsupportedOperationException("Not yet implemented");
    }
}
