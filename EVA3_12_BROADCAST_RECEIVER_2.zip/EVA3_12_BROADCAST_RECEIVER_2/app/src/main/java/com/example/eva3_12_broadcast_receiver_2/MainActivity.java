package com.example.eva3_12_broadcast_receiver_2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView txtVwDatos;
    BroadcastReceiver brReceiver;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txtVwDatos = findViewById(R.id.txtVwDatos);
        brReceiver = new MiReceptosDifusion();
        IntentFilter filtro = new IntentFilter("MI_SERVICIO");
        registerReceiver(brReceiver, filtro);
    }
    class MiReceptosDifusion extends BroadcastReceiver{
        @Override
        public void onReceive(Context context, Intent intent) {
            txtVwDatos.append(intent.getStringExtra("MENSAJE"));
        }
    }
}
