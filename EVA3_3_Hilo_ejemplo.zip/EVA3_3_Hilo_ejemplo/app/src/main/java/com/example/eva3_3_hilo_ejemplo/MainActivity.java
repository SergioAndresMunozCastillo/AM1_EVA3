package com.example.eva3_3_hilo_ejemplo;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.widget.ImageView;

import java.io.InputStream;
import java.net.URL;

public class MainActivity extends AppCompatActivity {
    ImageView imgVwMostrar;
    Bitmap image = null;
    Handler hansel = new Handler(){
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            imgVwMostrar.setImageBitmap(image);
        }
    };
    Thread hilo = new Thread(){
        @Override
        public void run() {
            super.run();
            image = cargarImagen("https://i.imgur.com/HPAfrqE.jpg");
            Message msg = hansel.obtainMessage();
            hansel.sendMessage(msg);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        imgVwMostrar = findViewById(R.id.imgVwMostrar);
        hilo.start();
        //Bitmap bitmap = cargarImagen( "");
        //imgVwMostrar.setImageBitmap(bitmap);
    }

    private Bitmap cargarImagen(String url) {
        Bitmap imagen = null;
        try{
            InputStream input = (InputStream)new URL(url).getContent();
            imagen = BitmapFactory.decodeStream(input);
        }catch(Exception e){
            e.printStackTrace();
        }
        return imagen;
    }
}
