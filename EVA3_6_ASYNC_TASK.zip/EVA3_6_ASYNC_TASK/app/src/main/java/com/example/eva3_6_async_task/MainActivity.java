package com.example.eva3_6_async_task;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {
    TextView txtVwMostrar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txtVwMostrar = findViewById(R.id.txtVwMostrar);
        MiClaseAsin miClase = new MiClaseAsin();
        miClase.execute(20, 500);
    }
}

class MiClaseAsin extends AsyncTask <Integer, String, String> {
    //TODOS PUEDEN INTERACTUAR CON LA UI, EXCEPTO doInBackground
    @Override
    protected void OnPreExecute(){
        super.onPreExecute();
        txtVwMostrar.setText("Inicia la app");
    }

    @Override
    protected String onProgressUpdate(String... values){
        super.onProgressUpdate(values);
        txtVwMostrar.append(values[0]);
    }

    @Override
    protected String doInBackground(String... strings){
        int iVeces = Integers[0];
        int iDemora[1];
        for (int i = 0; i<iVeces; i++){
            try{
                Thread.sleep(iDemora);
                publishProgress(i + " - ");
            } catch(InterruptedException e){
                e.printStackTrace();
            }
        }
        return "FIN DEL ASYNKTASK";
    }

    @Override
    protected String onPostExecute(String s){
        super.onPreExecute(s);
        txtVwMostrar.append(s);
    }
}
