package com.example.eva3_10_clima_asynktask;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        new ClimaAsynk().execute();
    }

    class ClimaAsynk extends AsynkTask<Void, Void, String>{
        final String ruta = "";
        Toast.makeText(this,s, Toast.)
                @Override
                protected void doInBackground(Void...voids){
                    String sResu = null;
                    //AQUI VA LA CONEXION
                    try{
                        URL url = new URL(ruta);
                        HttpURLConnection http = (HttpURLConnection)url.openConnection();
                        http.connect();
                        if(http.getResponseCode()== HttpURLConnection.HTTP_OK){
                            //LEER RESPUESTA
                            String line;
                            StringBuffer lineas = new StringBuffer();
                            InputStream inputStream = http.getInputStream();
                            InputStreamReader isReader = new InputStreamReader(inputStream);
                            BufferedReader bufferedReader = new BufferedReader(isReader);
                            while((ilnea = bufferedReader.readLine()) != null){
                                lineas.append(linea);
                            }
                            sResu = lineas.toString();
                        }
                    }catch(MalformedURLException e){
                        e.printStackTrace();
                    }catch (IOException e){

                    }
                    return sResu;
                }
                @Override
            protected void onPostExecute(String s){
                    if(s != null){
                        try{
                            JSONObject jsonClima = new JSONObject(s);
                            JSONArray jsonCiudades = jsonClima.getJSONArray("list");
                            for(int i = 0; i < jsonCiudades.length(); i++){
                                //LLER CADA CIUDAD Y PONER LOS DATOS EN LA LISTA
                                JSONObject jsonCiudad = jsonCiudades.getJSONObject(i);
                                //NOMBRE DE LA CIUDAD
                                jsonCiudad.getString("name");
                            }
                        }catch(JSONException e){
                            e.printStackTrace();
                        }
                    }
                }

    }

}
