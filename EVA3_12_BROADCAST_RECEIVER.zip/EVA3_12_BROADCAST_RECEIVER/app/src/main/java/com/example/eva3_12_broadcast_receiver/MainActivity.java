package com.example.eva3_12_broadcast_receiver;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.os.strictmode.IntentReceiverLeakedViolation;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    //CREAR DOS BOTONES Y UN TEXTVIEW
//CREAR DOS EVENTOS, UNO POR CADA BOTON
    TextView txtVwDatos;
    Intent inServicio;
    BroadcastReceiver brReceptor;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txtVwDatos = findViewById(R.id.txtVwDatos);
        inServicio = new Intent(this, Servicio.class);
        brReceptor = new MiReceptosDifusion();
        IntentFilter filtro = new IntentFilter("MI_SERVICIO");
        registerReceiver(brReceptor, filtro);
    }
    public void inicioServicio(View v){
        startService(inServicio);
    }

    public void detenerServicio(View v){
        stopService(inServicio);
    }

    class MiReceptosDifusion extends BroadcastReceiver{
        @Override
        public void onReceive(Context context, Intent intent) {
            txtVwDatos.append(intent.getStringExtra("MENSAJE"));
        }
    }
}
